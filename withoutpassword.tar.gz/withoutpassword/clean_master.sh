rm -rf /root/.ssh
