yum install expect -y
ssh-keygen -t rsa -P '' -f /root/.ssh/id_rsa
