#!/bin/bash
source /etc/profile
echo "172.18.1.6	datanode" >> /etc/hosts
./total.sh
hdfs namenode -format
ssh 172.18.1.6 "source /etc/profile"
ssh 172.18.1.6 "/root/path.sh 172.18.1.5 namenode"
start-dfs.sh
